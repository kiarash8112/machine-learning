import pandas as pd
import numpy as np

ds1 = pd.read_csv('D:\\datasets\\diabetes\\diabetes.csv')
described_one = ds1.describe().T
described_one['new col'] = described_one['mean'] / described_one['std']
described_one

ds2 = pd.read_csv('D:\\datasets\\student-dataset\\student-dataset.csv')
mean = ds2[['math.grade' , 'sciences.grade' , 'english.grade' , 'refletter.rating' , 'portfolio.rating']].groupby(by = 'portfolio.rating').mean()
std = ds2[['math.grade' , 'sciences.grade' , 'english.grade' , 'refletter.rating' , 'portfolio.rating']].groupby(by = 'portfolio.rating').var()
display(mean)
print('\n')
display(std)

