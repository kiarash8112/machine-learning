import numpy as np
A = np.random.randint(-10,11,size=(10,10))
# Convert the array to float
A = A.astype(float)
column_means = np.mean(A, axis=0)
print("Original array:")
print(A)
print("\nColumn means:")
print(column_means)
ans = np.where(A != 0 , A, column_means)
print("\nArray after replacing zeros with column means:")
print(ans)

import numpy as np
# Define the set of characters
chars1 = np.array(['a', 'b', 'c', 'd', 'e'])
chars2 = np.array(['a', 'b', 'c', 'd', 'e', 'f'])
# Create a 10x10 array with random choices from the set of characters
A = np.random.choice(chars1, size=(100, 20))
B = np.random.choice(chars2, size=(100, 40))
print("\nA")
print(A)
print("\nB")
print(B)
mask = np.equal(A, B[:, :20])
B[:, :20][mask] = "-"
print("Modified B:")
print(B)




